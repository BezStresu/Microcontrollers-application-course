#ifndef DELAY_H_
#define DELAY_H_

void delay(unsigned int msDelay);

#endif